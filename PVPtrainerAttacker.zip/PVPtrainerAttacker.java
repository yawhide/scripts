package scripts;

import java.awt.Graphics;
import java.util.Date;

import org.tribot.api.Clicking;
import org.tribot.api.General;
import org.tribot.api.input.Mouse;
import org.tribot.api.util.ABCUtil;
import org.tribot.api2007.Camera;
import org.tribot.api2007.GameTab;
import org.tribot.api2007.NPCChat;
import org.tribot.api2007.Objects;
import org.tribot.api2007.Skills;
import org.tribot.api2007.GameTab.TABS;
import org.tribot.api2007.Skills.SKILLS;
import org.tribot.api2007.types.RSObject;
import org.tribot.script.Script;
import org.tribot.script.interfaces.Painting;

public class PVPtrainerAttacker extends Script implements Painting{

	boolean scriptStatus = true;
	ABCUtil abc_util = null;
	int style = 2;
	long startTime;
	final int[] XP = {Skills.getXP(SKILLS.ATTACK), Skills.getXP(SKILLS.STRENGTH), 
	    		Skills.getXP(SKILLS.DEFENCE), Skills.getXP(SKILLS.RANGED), 
	    		Skills.getXP(SKILLS.PRAYER), Skills.getXP(SKILLS.MAGIC), 
	    		Skills.getXP(SKILLS.HITPOINTS), Skills.getXP(SKILLS.SLAYER)};
	final SKILLS[] Names = {SKILLS.ATTACK, SKILLS.STRENGTH, 
				SKILLS.DEFENCE, SKILLS.RANGED, 
				SKILLS.PRAYER, SKILLS.MAGIC, 
				SKILLS.HITPOINTS, SKILLS.SLAYER};
	int[] startLvs = {Skills.getActualLevel(SKILLS.ATTACK), Skills.getActualLevel(SKILLS.STRENGTH), 
				Skills.getActualLevel(SKILLS.DEFENCE), Skills.getActualLevel(SKILLS.RANGED), 
				Skills.getActualLevel(SKILLS.PRAYER), Skills.getActualLevel(SKILLS.MAGIC), 
				Skills.getActualLevel(SKILLS.HITPOINTS), Skills.getActualLevel(SKILLS.SLAYER), 
	};
	int startLvStr, startLvHP; 
	
	@Override
	public void onPaint(Graphics g) {
		g.drawString("version: 1.1", 5, 100);
		g.drawString((abc_util.TIME_TRACKER.CHECK_XP.next()- System.currentTimeMillis()) + "", 5, 115);
		g.drawString(RSUtil.getXpGainedAnHour(SKILLS.STRENGTH, XP[1], startTime), 360, 20);
		g.drawString(RSUtil.getXpGainedAnHour(SKILLS.HITPOINTS, XP[6], startTime), 360, 35);
		g.drawString("Str: " + startLvStr + "(" + (Skills.getActualLevel(SKILLS.STRENGTH) - startLvStr) +")", 360, 50);
		g.drawString("HP: " + startLvHP + "(" + (Skills.getActualLevel(SKILLS.HITPOINTS) - startLvHP) +")", 360, 65);
		Date date = new Date(la);
		g.drawString("Current LA: " + date.toString(), 5, 130);
	}
	
	long la;

	@Override
	public void run() {
		startTime = System.currentTimeMillis();
		abc_util = new ABCUtil();
		startLvStr = Skills.getActualLevel(SKILLS.STRENGTH);
		startLvHP = Skills.getActualLevel(SKILLS.HITPOINTS);
		updateLA();
		
		while(scriptStatus){
			
			
			checkAntiBan();
			checkChat();
			
			sleep(100);
		}
	}
	
	public void checkAntiBan(){
		if(abc_util.TIME_TRACKER.CHECK_XP.next() <= System.currentTimeMillis()){
			println("checking xp");
			checkXp();
			abc_util.TIME_TRACKER.CHECK_XP.reset();
			updateLA();
		}
		if (abc_util.TIME_TRACKER.ROTATE_CAMERA.next() != 0){
			println("rotating camera");
			Camera.setCameraRotation(General.random(0, 355));
			abc_util.TIME_TRACKER.ROTATE_CAMERA.reset();
			updateLA();
		}
		if (abc_util.TIME_TRACKER.EXAMINE_OBJECT.next() != 0){
			println("Examining a random object");
			RSObject[] random = Objects.getAll(10);
			if(random.length > 0){
				Clicking.click("Examine", random);
			}
			abc_util.TIME_TRACKER.EXAMINE_OBJECT.reset();
			updateLA();
		}
	}
	
	public void checkChat(){
		if(NPCChat.getMessage() != null){
			NPCChat.clickContinue(true);
			updateLA();
		}
	}
	
	public void checkXp(){
		GameTab.open(TABS.STATS);
		sleep(200,300);
		if(style == 2)
			Mouse.moveBox(555, 243, 604, 264);
		else if (style == 1)
			Mouse.moveBox(554, 211, 603, 232);
		else if (style == 4)
			Mouse.moveBox(552, 306, 604, 325);
		updateLA();
		sleep(2000, 5000);
	}
	
	public void updateLA(){
		la = System.currentTimeMillis();
	}

}
